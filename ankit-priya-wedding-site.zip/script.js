// nav scroll + mobile menu
const nav=document.getElementById('nav'),burger=document.getElementById('burger'),navlinks=document.getElementById('navlinks');
window.addEventListener('scroll',()=>nav.classList.toggle('scrolled',window.scrollY>60));
burger.addEventListener('click',()=>navlinks.classList.toggle('open'));
navlinks.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>navlinks.classList.remove('open')));

// floating petals
const petalsEl=document.getElementById('petals');
for(let i=0;i<18;i++){const p=document.createElement('div');p.className='petal';
  p.style.left=Math.random()*100+'%';p.style.animationDuration=(10+Math.random()*12)+'s';
  p.style.animationDelay=(Math.random()*12)+'s';p.style.width=p.style.height=(6+Math.random()*8)+'px';
  petalsEl.appendChild(p);}

// countdown
const target=new Date('2026-11-23T00:00:00');
function tick(){
  const now=new Date(); const diff=target-now;
  if(diff<=0){document.getElementById('countdown').style.display='none';document.getElementById('cd-done').style.display='block';clearInterval(timer);return;}
  const d=Math.floor(diff/86400000),h=Math.floor(diff/3600000%24),m=Math.floor(diff/60000%60),s=Math.floor(diff/1000%60);
  document.getElementById('cd-d').textContent=String(d).padStart(2,'0');
  document.getElementById('cd-h').textContent=String(h).padStart(2,'0');
  document.getElementById('cd-m').textContent=String(m).padStart(2,'0');
  document.getElementById('cd-s').textContent=String(s).padStart(2,'0');
}
tick();const timer=setInterval(tick,1000);

// gallery lightbox
const lb=document.getElementById('lightbox'),lbBox=document.getElementById('lbBox');
document.querySelectorAll('.g-tile').forEach(t=>t.addEventListener('click',()=>{
  lbBox.className='box '+t.className.replace('g-tile ','');
  lbBox.textContent=t.dataset.label;
  lbBox.style.display='flex';lbBox.style.alignItems='center';lbBox.style.justifyContent='center';
  lbBox.style.color='rgba(255,255,255,.85)';lbBox.style.fontFamily="'Cormorant Garamond',serif";lbBox.style.fontStyle='italic';lbBox.style.fontSize='1.3rem';
  lb.classList.add('open');
}));
document.getElementById('lbClose').addEventListener('click',()=>lb.classList.remove('open'));
lb.addEventListener('click',e=>{if(e.target===lb)lb.classList.remove('open');});

// wishes form
const form=document.getElementById('wishForm'),list=document.getElementById('wishesList');
const STORE='wedding_wishes_ankit_priya';
function loadWishes(){
  let arr=[];try{arr=JSON.parse(localStorage.getItem(STORE))||[];}catch(e){arr=[];}
  list.innerHTML='';
  arr.forEach(w=>{
    const el=document.createElement('div');el.className='wish-card';
    el.innerHTML=`<b>${escapeHtml(w.name)}</b><p>"${escapeHtml(w.msg)}"</p>`;
    list.prepend(el);
  });
}
function escapeHtml(s){const d=document.createElement('div');d.textContent=s;return d.innerHTML;}
loadWishes();
form.addEventListener('submit',e=>{
  e.preventDefault();
  const name=document.getElementById('wName').value.trim();
  const msg=document.getElementById('wMsg').value.trim();
  let ok=true;
  document.getElementById('errName').style.display=name?'none':'block';
  document.getElementById('errMsg').style.display=msg?'none':'block';
  if(!name||!msg)ok=false;
  if(!ok)return;
  let arr=[];try{arr=JSON.parse(localStorage.getItem(STORE))||[];}catch(e){arr=[];}
  arr.push({name,msg});
  try{localStorage.setItem(STORE,JSON.stringify(arr));}catch(e){}
  loadWishes();
  form.reset();
  const s=document.getElementById('successMsg');s.style.display='block';
  setTimeout(()=>s.style.display='none',4000);
});

// music toggle (no audio asset bundled; graceful no-op if unsupported)
const musicBtn=document.getElementById('musicBtn');
let playing=false;
musicBtn.addEventListener('click',()=>{
  playing=!playing;
  musicBtn.textContent=playing?'Ⅱ Pause Music':'♪ Play Music';
});